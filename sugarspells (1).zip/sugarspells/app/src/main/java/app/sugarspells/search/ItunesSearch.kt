package app.sugarspells.search

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

enum class SearchKind(val entity: String) {
    Songs("song"),
    Albums("album"),
}

data class SearchResult(
    val title: String,
    val subtitle: String,
    val artworkUrl: String?,
    /** music.apple.com link; the Apple Music app opens it. */
    val openUrl: String?,
)

/**
 * Apple's public iTunes Search API (no key, no account). It searches the catalogue and returns
 * links that the official Apple Music app opens. It cannot read your library or playlists.
 */
class ItunesSearch {

    suspend fun search(term: String, kind: SearchKind, country: String): List<SearchResult> =
        withContext(Dispatchers.IO) {
            if (term.isBlank()) return@withContext emptyList()
            runCatching {
                val url = "https://itunes.apple.com/search?term=${enc(term)}&media=music" +
                    "&entity=${kind.entity}&limit=30&country=${country.lowercase()}"
                val body = httpGet(url)
                if (body == null) emptyList() else parse(body, kind)
            }.getOrDefault(emptyList())
        }

    private fun parse(body: String, kind: SearchKind): List<SearchResult> {
        val results = JSONObject(body).optJSONArray("results") ?: return emptyList()
        val album = kind == SearchKind.Albums
        val out = ArrayList<SearchResult>()
        for (i in 0 until results.length()) {
            val o = results.getJSONObject(i)
            val title = if (album) o.optString("collectionName") else o.optString("trackName")
            if (title.isBlank()) continue
            val artist = o.optString("artistName")
            val subtitle = if (album) {
                artist
            } else {
                listOf(artist, o.optString("collectionName")).filter { it.isNotBlank() }.joinToString(" - ")
            }
            val artwork = o.optString("artworkUrl100").takeIf { it.isNotBlank() }
                ?.replace("100x100bb", "300x300bb")
            val link = (if (album) o.optString("collectionViewUrl") else o.optString("trackViewUrl"))
                .takeIf { it.isNotBlank() }
            out += SearchResult(title, subtitle, artwork, link)
        }
        return out
    }

    private fun httpGet(url: String): String? {
        val conn = URL(url).openConnection() as HttpURLConnection
        return try {
            conn.connectTimeout = 8_000
            conn.readTimeout = 8_000
            if (conn.responseCode != HttpURLConnection.HTTP_OK) null
            else conn.inputStream.bufferedReader().use { it.readText() }
        } finally {
            conn.disconnect()
        }
    }

    private fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")
}
