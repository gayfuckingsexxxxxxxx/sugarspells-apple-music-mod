package app.sugarspells.ui.common

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.LruCache
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.produceState
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

private val cache = object : LruCache<String, Bitmap>(16 * 1024 * 1024) {
    override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
}

/** Tiny dependency-free image loader with an in-memory cache. */
@Composable
fun rememberRemoteImage(url: String?): State<ImageBitmap?> =
    produceState<ImageBitmap?>(initialValue = null, key1 = url) {
        value = null
        if (url == null) return@produceState
        val bitmap = cache.get(url) ?: withContext(Dispatchers.IO) { download(url) }?.also { cache.put(url, it) }
        value = bitmap?.asImageBitmap()
    }

private fun download(url: String): Bitmap? = runCatching {
    val conn = URL(url).openConnection() as HttpURLConnection
    try {
        conn.connectTimeout = 8_000
        conn.readTimeout = 8_000
        if (conn.responseCode == HttpURLConnection.HTTP_OK) {
            conn.inputStream.use { BitmapFactory.decodeStream(it) }
        } else {
            null
        }
    } finally {
        conn.disconnect()
    }
}.getOrNull()
