package app.sugarspells.ui.player

import android.graphics.Bitmap
import android.os.Build
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.palette.graphics.Palette
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private val DefaultA = Color(0xFF3A2430)
private val DefaultB = Color(0xFF1A1216)

/**
 * Player background: drifting colour blobs from the cover's palette, plus a heavily blurred,
 * cross-fading copy of the cover itself (Android 12+). The glass panels sit on top of it.
 */
@Composable
fun Backdrop(
    artwork: Bitmap?,
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit,
) {
    var target by remember { mutableStateOf(DefaultA to DefaultB) }
    LaunchedEffect(artwork) {
        target = if (artwork == null) {
            DefaultA to DefaultB
        } else {
            val palette = withContext(Dispatchers.Default) {
                Palette.from(artwork).maximumColorCount(16).generate()
            }
            val a = palette.getDarkVibrantColor(palette.getDominantColor(DefaultA.toArgb()))
            val b = palette.getMutedColor(palette.getVibrantColor(DefaultB.toArgb()))
            Color(a) to Color(b)
        }
    }
    val colorA by animateColorAsState(target.first, tween(1_400), label = "backdropA")
    val colorB by animateColorAsState(target.second, tween(1_400), label = "backdropB")

    val transition = rememberInfiniteTransition(label = "backdropDrift")
    val drift by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(16_000, easing = LinearEasing), RepeatMode.Reverse),
        label = "drift",
    )

    Box(
        modifier = modifier
            .background(Color.Black)
            .drawBehind {
                val radius = size.maxDimension * 0.95f
                drawRect(
                    Brush.radialGradient(
                        listOf(colorA, Color.Transparent),
                        center = Offset(size.width * (0.15f + 0.45f * drift), size.height * (0.2f + 0.2f * drift)),
                        radius = radius,
                    ),
                )
                drawRect(
                    Brush.radialGradient(
                        listOf(colorB, Color.Transparent),
                        center = Offset(size.width * (0.85f - 0.45f * drift), size.height * (0.85f - 0.25f * drift)),
                        radius = radius,
                    ),
                )
            },
    ) {
        // Modifier.blur only works on Android 12+; below that the sharp cover would show through.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            Crossfade(targetState = artwork, animationSpec = tween(1_200), label = "backdropCover") { art ->
                if (art != null) {
                    val image = remember(art) { art.asImageBitmap() }
                    Image(
                        bitmap = image,
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .fillMaxSize()
                            .graphicsLayer {
                                scaleX = 1.4f
                                scaleY = 1.4f
                                alpha = 0.55f
                            }
                            .blur(80.dp),
                    )
                }
            }
        }
        Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.12f)))
        content()
    }
}
