package app.sugarspells.ui.theme

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import java.io.File

/**
 * Lets the user load their own font files (.ttf / .otf) from device storage, e.g. one file per weight.
 * Files are copied to the app's private storage, so nothing font-related lives in the repo or the APK.
 * The weight of each file is guessed from its name (Regular, Medium, Semibold, Bold...).
 */
class FontStore(private val context: Context) {
    private val dir = File(context.filesDir, "fonts").apply { mkdirs() }

    fun import(uris: List<Uri>) {
        for (uri in uris) {
            val name = displayName(uri) ?: continue
            if (!name.endsWith(".ttf", ignoreCase = true) && !name.endsWith(".otf", ignoreCase = true)) continue
            val target = File(dir, name.replace(Regex("[^A-Za-z0-9._-]"), "_"))
            context.contentResolver.openInputStream(uri)?.use { input ->
                target.outputStream().use { output -> input.copyTo(output) }
            }
        }
    }

    /** Null when no custom font has been imported. Italic files are skipped. */
    fun load(): FontFamily? {
        val fonts = dir.listFiles().orEmpty()
            .filter { it.extension.lowercase() in setOf("ttf", "otf") && !it.name.contains("italic", ignoreCase = true) }
            .map { Font(it, weightFor(it.name)) }
        return if (fonts.isEmpty()) null else FontFamily(fonts)
    }

    fun clear() {
        dir.listFiles()?.forEach { it.delete() }
    }

    private fun displayName(uri: Uri): String? =
        context.contentResolver
            .query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { cursor -> if (cursor.moveToFirst()) cursor.getString(0) else null }

    private fun weightFor(fileName: String): FontWeight {
        val n = fileName.lowercase()
        return when {
            "ultralight" in n || "thin" in n -> FontWeight.Thin
            "light" in n -> FontWeight.Light
            "semibold" in n || "semi-bold" in n -> FontWeight.SemiBold
            "extrabold" in n -> FontWeight.ExtraBold
            "black" in n || "heavy" in n -> FontWeight.Black
            "bold" in n -> FontWeight.Bold
            "medium" in n -> FontWeight.Medium
            else -> FontWeight.Normal
        }
    }
}
