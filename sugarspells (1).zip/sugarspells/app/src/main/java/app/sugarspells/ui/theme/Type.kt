package app.sugarspells.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import app.sugarspells.R

/** Inter is the closest open-licence typeface to Apple's San Francisco (which cannot be bundled). */
val Inter = FontFamily(
    Font(R.font.inter_regular, FontWeight.Normal),
    Font(R.font.inter_medium, FontWeight.Medium),
    Font(R.font.inter_semibold, FontWeight.SemiBold),
    Font(R.font.inter_bold, FontWeight.Bold),
)

/** Optical size for large text, like SF Pro Display. */
val InterDisplay = FontFamily(
    Font(R.font.interdisplay_semibold, FontWeight.SemiBold),
    Font(R.font.interdisplay_bold, FontWeight.Bold),
)

val AppTypography = Typography(
    headlineLarge = TextStyle(
        fontFamily = InterDisplay, fontWeight = FontWeight.Bold,
        fontSize = 40.sp, lineHeight = 46.sp, letterSpacing = (-0.9).sp,
    ),
    headlineMedium = TextStyle(
        fontFamily = InterDisplay, fontWeight = FontWeight.Bold,
        fontSize = 32.sp, lineHeight = 38.sp, letterSpacing = (-0.6).sp,
    ),
    headlineSmall = TextStyle(
        fontFamily = InterDisplay, fontWeight = FontWeight.Bold,
        fontSize = 26.sp, lineHeight = 32.sp, letterSpacing = (-0.4).sp,
    ),
    titleLarge = TextStyle(
        fontFamily = InterDisplay, fontWeight = FontWeight.SemiBold,
        fontSize = 24.sp, lineHeight = 30.sp, letterSpacing = (-0.3).sp,
    ),
    titleMedium = TextStyle(
        fontFamily = Inter, fontWeight = FontWeight.SemiBold,
        fontSize = 17.sp, lineHeight = 22.sp, letterSpacing = (-0.2).sp,
    ),
    bodyLarge = TextStyle(
        fontFamily = Inter, fontWeight = FontWeight.Normal,
        fontSize = 17.sp, lineHeight = 24.sp, letterSpacing = (-0.2).sp,
    ),
    bodyMedium = TextStyle(
        fontFamily = Inter, fontWeight = FontWeight.Normal,
        fontSize = 15.sp, lineHeight = 21.sp, letterSpacing = (-0.1).sp,
    ),
    labelLarge = TextStyle(
        fontFamily = Inter, fontWeight = FontWeight.Medium,
        fontSize = 14.sp, lineHeight = 20.sp,
    ),
    labelSmall = TextStyle(
        fontFamily = Inter, fontWeight = FontWeight.Medium,
        fontSize = 12.sp, lineHeight = 16.sp,
    ),
)

/** The app typography, optionally with every style switched to a user-loaded font family. */
fun typographyWith(family: FontFamily?): Typography =
    if (family == null) {
        AppTypography
    } else {
        Typography(
            headlineLarge = AppTypography.headlineLarge.copy(fontFamily = family),
            headlineMedium = AppTypography.headlineMedium.copy(fontFamily = family),
            headlineSmall = AppTypography.headlineSmall.copy(fontFamily = family),
            titleLarge = AppTypography.titleLarge.copy(fontFamily = family),
            titleMedium = AppTypography.titleMedium.copy(fontFamily = family),
            bodyLarge = AppTypography.bodyLarge.copy(fontFamily = family),
            bodyMedium = AppTypography.bodyMedium.copy(fontFamily = family),
            labelLarge = AppTypography.labelLarge.copy(fontFamily = family),
            labelSmall = AppTypography.labelSmall.copy(fontFamily = family),
        )
    }
