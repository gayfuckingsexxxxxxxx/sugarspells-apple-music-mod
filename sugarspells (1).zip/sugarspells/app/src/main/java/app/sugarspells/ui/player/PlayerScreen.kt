package app.sugarspells.ui.player

import android.content.Context
import android.media.AudioManager
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import app.sugarspells.ui.common.LyricsIcon
import app.sugarspells.ui.common.QueueIcon
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.sugarspells.R
import app.sugarspells.lyrics.Lyrics
import app.sugarspells.lyrics.LyricsRepository
import app.sugarspells.lyrics.TrackQuery
import app.sugarspells.playback.EngineState
import app.sugarspells.playback.NowPlaying
import app.sugarspells.playback.PlaybackEngine
import app.sugarspells.ui.theme.glass
import kotlinx.coroutines.delay
import kotlin.math.abs
import kotlin.math.roundToInt

private sealed interface LyricsUi {
    data object Loading : LyricsUi
    data object Missing : LyricsUi
    data class Found(val lyrics: Lyrics) : LyricsUi
}

@Composable
fun PlayerScreen(
    state: EngineState,
    engine: PlaybackEngine,
    lyricsRepository: LyricsRepository,
    onGrantAccess: () -> Unit,
    onOpenAppleMusic: () -> Unit,
    onPickFont: () -> Unit,
    hasCustomFont: Boolean,
    onResetFont: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Box(modifier.fillMaxSize()) {
        when (state) {
            EngineState.NoAccess -> CenteredMessage(
                title = stringResource(R.string.access_title),
                body = stringResource(R.string.access_body),
                action = stringResource(R.string.access_action),
                onAction = onGrantAccess,
            )

            EngineState.NoSession -> CenteredMessage(
                title = stringResource(R.string.no_session_title),
                body = stringResource(R.string.no_session_body),
                action = stringResource(R.string.open_apple_music),
                onAction = onOpenAppleMusic,
            )

            is EngineState.Ready -> NowPlayingLayout(
                np = state.nowPlaying,
                engine = engine,
                repository = lyricsRepository,
                onOpenAppleMusic = onOpenAppleMusic,
                onPickFont = onPickFont,
                hasCustomFont = hasCustomFont,
                onResetFont = onResetFont,
            )
        }
    }
}

@Composable
private fun CenteredMessage(title: String, body: String, action: String, onAction: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .safeDrawingPadding()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Text(title, style = MaterialTheme.typography.headlineSmall, textAlign = TextAlign.Center)
        Spacer(Modifier.height(12.dp))
        Text(body, style = MaterialTheme.typography.bodyMedium, textAlign = TextAlign.Center)
        Spacer(Modifier.height(24.dp))
        Button(onClick = onAction) { Text(action) }
    }
}

@Composable
private fun NowPlayingLayout(
    np: NowPlaying,
    engine: PlaybackEngine,
    repository: LyricsRepository,
    onOpenAppleMusic: () -> Unit,
    onPickFont: () -> Unit,
    hasCustomFont: Boolean,
    onResetFont: () -> Unit,
) {
    val position = rememberPositionMs(np)
    val query = remember(np.title, np.artist, np.album, np.durationMs) {
        TrackQuery(np.title, np.artist, np.album, np.durationMs)
    }
    val lyricsUi by produceState<LyricsUi>(LyricsUi.Loading, query) {
        value = LyricsUi.Loading
        val found = if (query.title.isBlank()) null else repository.load(query)
        value = if (found != null) LyricsUi.Found(found) else LyricsUi.Missing
    }
    val seekToFraction: (Float) -> Unit = { f -> engine.seekTo((f * np.durationMs).toLong()) }

    BoxWithConstraints(Modifier.fillMaxSize().safeDrawingPadding()) {
        if (maxWidth >= 600.dp) {
            TabletLayout(
                np, engine, position, lyricsUi, seekToFraction,
                onOpenAppleMusic, onPickFont, hasCustomFont, onResetFont,
                maxWidth, maxHeight,
            )
        } else {
            PhoneLayout(np, engine, position, lyricsUi, seekToFraction)
        }
    }
}

private enum class RightPane { Lyrics, Queue }

/** Landscape tablet, modelled on Apple Music for iPad: player on the left, lyrics or queue on the right. */
@Composable
private fun TabletLayout(
    np: NowPlaying,
    engine: PlaybackEngine,
    position: State<Long>,
    lyricsUi: LyricsUi,
    onSeekFraction: (Float) -> Unit,
    onOpenAppleMusic: () -> Unit,
    onPickFont: () -> Unit,
    hasCustomFont: Boolean,
    onResetFont: () -> Unit,
    availableWidth: Dp,
    availableHeight: Dp,
) {
    val horizontalPad = 44.dp
    val verticalPad = 36.dp
    val gap = 56.dp
    val leftMax = (availableWidth - horizontalPad * 2 - gap) * 0.4f
    // Room below the cover for title, progress, transport and volume.
    val coverSize = minOf(leftMax, availableHeight - verticalPad * 2 - 290.dp).coerceAtLeast(160.dp)
    var pane by remember { mutableStateOf(RightPane.Lyrics) }

    Box(Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxSize().padding(horizontal = horizontalPad, vertical = verticalPad),
            horizontalArrangement = Arrangement.spacedBy(gap),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.width(coverSize)) {
                Cover(np, Modifier.size(coverSize))
                Spacer(Modifier.height(18.dp))
                TrackInfo(np)
                Spacer(Modifier.height(10.dp))
                TimeBar(np, position, onSeekFraction)
                Spacer(Modifier.height(10.dp))
                Controls(np, engine)
                Spacer(Modifier.height(10.dp))
                VolumeRow()
            }
            Box(Modifier.weight(1f).fillMaxHeight()) {
                Crossfade(targetState = pane, animationSpec = tween(300), label = "rightPane") { current ->
                    when (current) {
                        RightPane.Lyrics -> LyricsArea(
                            ui = lyricsUi,
                            position = position,
                            onSeek = engine::seekTo,
                            large = true,
                            modifier = Modifier.fillMaxSize(),
                        )

                        RightPane.Queue -> QueuePane(np, engine, Modifier.fillMaxSize())
                    }
                }
            }
        }
        Row(
            modifier = Modifier.align(Alignment.BottomStart).padding(start = horizontalPad, bottom = 20.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            GlassChip(stringResource(R.string.open_apple_music), onOpenAppleMusic)
            GlassChip(stringResource(R.string.choose_font), onPickFont)
            if (hasCustomFont) GlassChip(stringResource(R.string.reset_font), onResetFont)
        }
        Row(
            modifier = Modifier.align(Alignment.BottomEnd).padding(end = horizontalPad, bottom = 20.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            PaneToggle(selected = pane == RightPane.Lyrics, onClick = { pane = RightPane.Lyrics }) { LyricsIcon() }
            PaneToggle(selected = pane == RightPane.Queue, onClick = { pane = RightPane.Queue }) { QueueIcon() }
        }
    }
}

@Composable
private fun PaneToggle(selected: Boolean, onClick: () -> Unit, icon: @Composable () -> Unit) {
    val shape = RoundedCornerShape(12.dp)
    Box(
        modifier = Modifier
            .size(44.dp)
            .then(if (selected) Modifier.glass(shape = shape, tint = 0.24f, elevation = 0.dp) else Modifier)
            .pressable(onClick),
        contentAlignment = Alignment.Center,
    ) {
        icon()
    }
}

/** Fallback for small screens (the app is designed for tablets). */
@Composable
private fun PhoneLayout(
    np: NowPlaying,
    engine: PlaybackEngine,
    position: State<Long>,
    lyricsUi: LyricsUi,
    onSeekFraction: (Float) -> Unit,
) {
    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            Cover(np, Modifier.size(96.dp))
            Column(Modifier.weight(1f)) { TrackInfo(np) }
        }
        LyricsArea(lyricsUi, position, engine::seekTo, large = false, modifier = Modifier.weight(1f).fillMaxWidth())
        TimeBar(np, position, onSeekFraction)
        Controls(np, engine)
    }
}

@Composable
private fun Cover(np: NowPlaying, modifier: Modifier) {
    // Shrinks when paused, springs back when playing (like Apple Music).
    val scale by animateFloatAsState(
        targetValue = if (np.isPlaying) 1f else 0.88f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow),
        label = "coverScale",
    )
    // Slow zoom and drift inside the frame while playing. This is a visual effect on the still cover,
    // not Apple's motion artwork (that comes from the paid Apple Music API).
    val transition = rememberInfiniteTransition(label = "coverMotion")
    val sweep by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(22_000, easing = LinearEasing), RepeatMode.Reverse),
        label = "coverSweep",
    )
    val alive by animateFloatAsState(if (np.isPlaying) 1f else 0f, tween(800), label = "coverAlive")
    val shape = RoundedCornerShape(14.dp)
    Box(
        modifier = modifier
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .shadow(28.dp, shape)
            .clip(shape)
            .background(Color.White.copy(alpha = 0.15f)),
        contentAlignment = Alignment.Center,
    ) {
        Crossfade(targetState = np.artwork, animationSpec = tween(700), label = "coverFade") { art ->
            if (art != null) {
                val image = remember(art) { art.asImageBitmap() }
                Image(
                    bitmap = image,
                    contentDescription = null,
                    modifier = Modifier
                        .fillMaxSize()
                        .graphicsLayer {
                            val zoom = 1f + 0.07f * sweep * alive
                            scaleX = zoom
                            scaleY = zoom
                            translationX = (sweep - 0.5f) * 24f * alive
                            translationY = (0.5f - sweep) * 16f * alive
                        },
                    contentScale = ContentScale.Crop,
                )
            } else {
                Text("🍎🎵", fontSize = 48.sp)
            }
        }
    }
}

@Composable
private fun TrackInfo(np: NowPlaying) {
    Text(
        np.title,
        style = MaterialTheme.typography.titleLarge,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
        modifier = Modifier.fillMaxWidth(),
    )
    Text(
        listOf(np.artist, np.album).filter { it.isNotBlank() }.joinToString(" - "),
        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Normal),
        color = Color.White.copy(alpha = 0.65f),
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
        modifier = Modifier.fillMaxWidth(),
    )
}

@Composable
private fun TimeBar(np: NowPlaying, position: State<Long>, onSeekFraction: (Float) -> Unit) {
    val pos = position.value
    val fraction = if (np.durationMs > 0) (pos.toFloat() / np.durationMs).coerceIn(0f, 1f) else 0f
    val remaining = (np.durationMs - pos).coerceAtLeast(0L)
    Column(Modifier.fillMaxWidth()) {
        ThinSlider(fraction = fraction, onValue = onSeekFraction, live = false, modifier = Modifier.fillMaxWidth())
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(formatTime(pos), style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha = 0.6f))
            Text("-" + formatTime(remaining), style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha = 0.6f))
        }
    }
}

@Composable
private fun Controls(np: NowPlaying, engine: PlaybackEngine) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.pressable(engine::previous).padding(12.dp)) { SkipIcon(forward = false, dimension = 44.dp) }
        Box(Modifier.pressable { if (np.isPlaying) engine.pause() else engine.play() }.padding(12.dp)) {
            Crossfade(targetState = np.isPlaying, animationSpec = tween(200), label = "playPause") { playing ->
                PlayPauseIcon(playing = playing, dimension = 56.dp)
            }
        }
        Box(Modifier.pressable(engine::next).padding(12.dp)) { SkipIcon(forward = true, dimension = 44.dp) }
    }
}

/** System media volume, kept in sync with the hardware buttons. */
@Composable
private fun VolumeRow() {
    val context = LocalContext.current
    val audio = remember { context.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    val maxVolume = remember { audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1) }
    var volume by remember { mutableFloatStateOf(audio.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / maxVolume) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(1_000)
            val system = audio.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / maxVolume
            if (abs(system - volume) > 0.5f / maxVolume) volume = system
        }
    }
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        SpeakerIcon(loud = false)
        ThinSlider(
            fraction = volume,
            onValue = { v ->
                volume = v
                audio.setStreamVolume(AudioManager.STREAM_MUSIC, (v * maxVolume).roundToInt(), 0)
            },
            live = true,
            modifier = Modifier.weight(1f).padding(horizontal = 10.dp),
        )
        SpeakerIcon(loud = true)
    }
}

@Composable
private fun GlassChip(text: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .glass(shape = CircleShape, tint = 0.12f, elevation = 6.dp)
            .pressable(onClick)
            .padding(horizontal = 16.dp, vertical = 8.dp),
    ) {
        Text(text, style = MaterialTheme.typography.labelLarge)
    }
}

@Composable
private fun LyricsArea(
    ui: LyricsUi,
    position: State<Long>,
    onSeek: (Long) -> Unit,
    large: Boolean,
    modifier: Modifier,
) {
    Box(modifier, contentAlignment = Alignment.Center) {
        when (ui) {
            LyricsUi.Loading -> CircularProgressIndicator(color = Color.White, modifier = Modifier.size(28.dp))
            LyricsUi.Missing -> Text(
                stringResource(R.string.no_lyrics),
                color = Color.White.copy(alpha = 0.6f),
                textAlign = TextAlign.Center,
            )

            is LyricsUi.Found -> LyricsPane(ui.lyrics, position, onSeek, large, Modifier.fillMaxSize())
        }
    }
}

// ---------------------------------------------------------------------------------------------
// Small building blocks
// ---------------------------------------------------------------------------------------------

/** Thin Apple-style bar. [live] = report while dragging (volume); otherwise only on release (seek). */
@Composable
private fun ThinSlider(
    fraction: Float,
    onValue: (Float) -> Unit,
    live: Boolean,
    modifier: Modifier = Modifier,
) {
    var dragging by remember { mutableStateOf<Float?>(null) }
    val shown = dragging ?: fraction
    val thickness by animateDpAsState(if (dragging != null) 9.dp else 5.dp, label = "sliderThickness")
    Box(
        modifier = modifier
            .height(28.dp)
            .pointerInput(live) {
                detectTapGestures { o -> onValue((o.x / size.width).coerceIn(0f, 1f)) }
            }
            .pointerInput(live) {
                detectHorizontalDragGestures(
                    onDragStart = { o ->
                        val v = (o.x / size.width).coerceIn(0f, 1f)
                        dragging = v
                        if (live) onValue(v)
                    },
                    onDragEnd = {
                        dragging?.let { if (!live) onValue(it) }
                        dragging = null
                    },
                    onDragCancel = { dragging = null },
                    onHorizontalDrag = { change, _ ->
                        val v = (change.position.x / size.width).coerceIn(0f, 1f)
                        dragging = v
                        if (live) onValue(v)
                    },
                )
            },
        contentAlignment = Alignment.CenterStart,
    ) {
        Box(Modifier.fillMaxWidth().height(thickness).clip(CircleShape).background(Color.White.copy(alpha = 0.3f)))
        Box(Modifier.fillMaxWidth(shown).height(thickness).clip(CircleShape).background(Color.White))
    }
}

/** Springy press feedback, no ripple. */
@Composable
private fun Modifier.pressable(onClick: () -> Unit): Modifier {
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.86f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
        label = "pressScale",
    )
    return this
        .graphicsLayer {
            scaleX = scale
            scaleY = scale
        }
        .clickable(interactionSource = source, indication = null, onClick = onClick)
}

private fun DrawScope.triangle(left: Float, top: Float, width: Float, height: Float, pointsRight: Boolean) {
    val path = Path().apply {
        if (pointsRight) {
            moveTo(left, top)
            lineTo(left + width, top + height / 2f)
            lineTo(left, top + height)
        } else {
            moveTo(left + width, top)
            lineTo(left, top + height / 2f)
            lineTo(left + width, top + height)
        }
        close()
    }
    drawPath(path, Color.White)
    // A thin round stroke softens the corners.
    drawPath(path, Color.White, style = Stroke(width = width * 0.14f, join = StrokeJoin.Round))
}

@Composable
private fun PlayPauseIcon(playing: Boolean, dimension: Dp) {
    Canvas(Modifier.size(dimension)) {
        val d = size.width
        if (playing) {
            val barWidth = d * 0.26f
            val barHeight = d * 0.78f
            val top = (d - barHeight) / 2f
            drawRoundRect(Color.White, Offset(d * 0.15f, top), Size(barWidth, barHeight), CornerRadius(barWidth * 0.3f))
            drawRoundRect(Color.White, Offset(d * 0.59f, top), Size(barWidth, barHeight), CornerRadius(barWidth * 0.3f))
        } else {
            triangle(d * 0.22f, d * 0.12f, d * 0.68f, d * 0.76f, pointsRight = true)
        }
    }
}

@Composable
private fun SkipIcon(forward: Boolean, dimension: Dp) {
    Canvas(Modifier.size(dimension)) {
        val d = size.width
        val w = d * 0.46f
        val h = d * 0.62f
        val top = (d - h) / 2f
        triangle(d * 0.04f, top, w, h, pointsRight = forward)
        triangle(d * 0.5f, top, w, h, pointsRight = forward)
    }
}

@Composable
private fun SpeakerIcon(loud: Boolean) {
    Canvas(Modifier.size(18.dp)) {
        val w = size.width
        val h = size.height
        val tint = Color.White.copy(alpha = 0.7f)
        val body = Path().apply {
            moveTo(w * 0.08f, h * 0.38f)
            lineTo(w * 0.28f, h * 0.38f)
            lineTo(w * 0.5f, h * 0.2f)
            lineTo(w * 0.5f, h * 0.8f)
            lineTo(w * 0.28f, h * 0.62f)
            lineTo(w * 0.08f, h * 0.62f)
            close()
        }
        drawPath(body, tint)
        val arcs = if (loud) 2 else 1
        for (i in 1..arcs) {
            val r = w * (0.14f + 0.14f * i)
            drawArc(
                color = tint,
                startAngle = -45f,
                sweepAngle = 90f,
                useCenter = false,
                topLeft = Offset(w * 0.5f - r, h * 0.5f - r),
                size = Size(r * 2f, r * 2f),
                style = Stroke(width = w * 0.08f, cap = StrokeCap.Round),
            )
        }
    }
}

private fun formatTime(ms: Long): String {
    val totalSeconds = (ms / 1000).coerceAtLeast(0)
    return "%d:%02d".format(totalSeconds / 60, totalSeconds % 60)
}
