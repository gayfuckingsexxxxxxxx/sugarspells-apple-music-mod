package app.sugarspells.playback

import android.content.ComponentName
import android.content.Context
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSession
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.SystemClock
import androidx.core.app.NotificationManagerCompat
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

const val APPLE_MUSIC_PACKAGE = "com.apple.android.music"

fun hasNotificationAccess(context: Context): Boolean =
    NotificationManagerCompat.getEnabledListenerPackages(context).contains(context.packageName)

/**
 * Free playback backend: reads and controls the media session published by the official
 * Apple Music app. Playback, DRM and the account stay entirely inside Apple's app.
 *
 * Reading media sessions requires the user to enable notification access for this app.
 * Only the media session of [APPLE_MUSIC_PACKAGE] is used; notification content is never read.
 */
class AppleMusicSessionEngine(context: Context) : PlaybackEngine {

    private val appContext = context.applicationContext
    private val manager = appContext.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
    private val listenerComponent = ComponentName(appContext, NotificationAccessService::class.java)

    private val _state = MutableStateFlow<EngineState>(EngineState.NoAccess)
    override val state: StateFlow<EngineState> = _state.asStateFlow()

    private var controller: MediaController? = null
    private var listening = false

    private val sessionsListener =
        MediaSessionManager.OnActiveSessionsChangedListener { controllers ->
            attach(controllers.orEmpty())
        }

    private val callback = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) {
            publish()
        }

        override fun onPlaybackStateChanged(state: PlaybackState?) {
            publish()
        }

        override fun onQueueChanged(queue: MutableList<MediaSession.QueueItem>?) {
            publish()
        }

        override fun onSessionDestroyed() {
            start()
        }
    }

    override fun start() {
        if (!hasNotificationAccess(appContext)) {
            _state.value = EngineState.NoAccess
            return
        }
        try {
            if (!listening) {
                manager.addOnActiveSessionsChangedListener(sessionsListener, listenerComponent)
                listening = true
            }
            attach(manager.getActiveSessions(listenerComponent))
        } catch (_: SecurityException) {
            _state.value = EngineState.NoAccess
        }
    }

    override fun stop() {
        controller?.unregisterCallback(callback)
        controller = null
        if (listening) {
            manager.removeOnActiveSessionsChangedListener(sessionsListener)
            listening = false
        }
    }

    private fun attach(controllers: List<MediaController>) {
        val next = controllers.firstOrNull { it.packageName == APPLE_MUSIC_PACKAGE }
        if (next?.sessionToken != controller?.sessionToken) {
            controller?.unregisterCallback(callback)
            controller = next
            next?.registerCallback(callback)
        }
        publish()
    }

    private fun publish() {
        val c = controller
        val metadata = c?.metadata
        if (c == null || metadata == null) {
            _state.value = EngineState.NoSession
            return
        }
        val playback = c.playbackState
        _state.value = EngineState.Ready(
            NowPlaying(
                title = metadata.getString(MediaMetadata.METADATA_KEY_TITLE).orEmpty(),
                artist = (metadata.getString(MediaMetadata.METADATA_KEY_ARTIST)
                    ?: metadata.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)).orEmpty(),
                album = metadata.getString(MediaMetadata.METADATA_KEY_ALBUM).orEmpty(),
                artwork = metadata.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
                    ?: metadata.getBitmap(MediaMetadata.METADATA_KEY_ART),
                durationMs = metadata.getLong(MediaMetadata.METADATA_KEY_DURATION),
                isPlaying = playback?.state == PlaybackState.STATE_PLAYING,
                positionMs = playback?.position ?: 0L,
                positionUpdatedAt = playback?.lastPositionUpdateTime ?: SystemClock.elapsedRealtime(),
                speed = playback?.playbackSpeed ?: 1f,
                queue = c.queue.orEmpty().map { item ->
                    val description = item.description
                    QueueEntry(
                        id = item.queueId,
                        title = description.title?.toString().orEmpty(),
                        subtitle = description.subtitle?.toString().orEmpty(),
                        artwork = description.iconBitmap,
                    )
                },
                activeQueueId = playback?.activeQueueItemId ?: -1L,
            ),
        )
    }

    override fun play() { controller?.transportControls?.play() }
    override fun pause() { controller?.transportControls?.pause() }
    override fun next() { controller?.transportControls?.skipToNext() }
    override fun previous() { controller?.transportControls?.skipToPrevious() }
    override fun seekTo(positionMs: Long) { controller?.transportControls?.seekTo(positionMs) }
    override fun skipToQueueItem(id: Long) { controller?.transportControls?.skipToQueueItem(id) }
}
