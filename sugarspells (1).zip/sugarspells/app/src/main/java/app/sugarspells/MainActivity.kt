package app.sugarspells

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import app.sugarspells.lyrics.LrclibProvider
import app.sugarspells.lyrics.LyricsRepository
import app.sugarspells.playback.APPLE_MUSIC_PACKAGE
import app.sugarspells.playback.AppleMusicSessionEngine
import app.sugarspells.playback.PlaybackEngine
import app.sugarspells.ui.AppShell
import app.sugarspells.ui.theme.FontStore
import app.sugarspells.ui.theme.SugarspellsTheme
import app.sugarspells.ui.theme.typographyWith

class MainActivity : ComponentActivity() {

    private lateinit var engine: PlaybackEngine
    private lateinit var fontStore: FontStore
    private val lyricsRepository = LyricsRepository(listOf(LrclibProvider()))
    private var customFont by mutableStateOf<FontFamily?>(null)

    private val pickFonts =
        registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
            if (uris.isNotEmpty()) {
                fontStore.import(uris)
                customFont = fontStore.load()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        engine = AppleMusicSessionEngine(this)
        fontStore = FontStore(this)
        customFont = fontStore.load()
        setContent {
            SugarspellsTheme(typography = typographyWith(customFont)) {
                Surface(modifier = Modifier.fillMaxSize()) {
                    val state by engine.state.collectAsState()
                    AppShell(
                        state = state,
                        engine = engine,
                        lyricsRepository = lyricsRepository,
                        onGrantAccess = ::openNotificationAccessSettings,
                        onOpenAppleMusic = ::openAppleMusic,
                        onPickFont = { pickFonts.launch(arrayOf("*/*")) },
                        hasCustomFont = customFont != null,
                        onResetFont = {
                            fontStore.clear()
                            customFont = null
                        },
                        onOpenUrl = ::openInAppleMusic,
                    )
                }
            }
        }
    }

    // Re-check on every return (e.g. coming back from the notification access settings).
    override fun onStart() {
        super.onStart()
        engine.start()
    }

    override fun onStop() {
        engine.stop()
        super.onStop()
    }

    private fun openNotificationAccessSettings() {
        startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
    }

    private fun openAppleMusic() {
        val launch = packageManager.getLaunchIntentForPackage(APPLE_MUSIC_PACKAGE)
        try {
            startActivity(
                launch ?: Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$APPLE_MUSIC_PACKAGE")),
            )
        } catch (_: ActivityNotFoundException) {
            // No Play Store available; nothing else to do.
        }
    }

    /** Opens a music.apple.com link in the Apple Music app, or the browser if the app can't take it. */
    private fun openInAppleMusic(url: String) {
        val inApp = Intent(Intent.ACTION_VIEW, Uri.parse(url)).setPackage(APPLE_MUSIC_PACKAGE)
        try {
            startActivity(inApp)
        } catch (_: ActivityNotFoundException) {
            try {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
            } catch (_: ActivityNotFoundException) {
                // Nothing can open the link.
            }
        }
    }
}
