package app.sugarspells.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import app.sugarspells.R
import app.sugarspells.lyrics.LyricsRepository
import app.sugarspells.playback.EngineState
import app.sugarspells.playback.PlaybackEngine
import app.sugarspells.search.SearchKind
import app.sugarspells.ui.common.NoteIcon
import app.sugarspells.ui.common.SearchIcon
import app.sugarspells.ui.common.pressable
import app.sugarspells.ui.player.Backdrop
import app.sugarspells.ui.player.PlayerScreen
import app.sugarspells.ui.search.SearchScreen
import app.sugarspells.ui.theme.glass

private enum class Destination { NowPlaying, Search }

/** Glass sidebar on tablets, bottom bar on phones. Both sit on the cover-coloured backdrop. */
@Composable
fun AppShell(
    state: EngineState,
    engine: PlaybackEngine,
    lyricsRepository: LyricsRepository,
    onGrantAccess: () -> Unit,
    onOpenAppleMusic: () -> Unit,
    onPickFont: () -> Unit,
    hasCustomFont: Boolean,
    onResetFont: () -> Unit,
    onOpenUrl: (String) -> Unit,
) {
    var destination by rememberSaveable { mutableStateOf(Destination.NowPlaying) }
    var query by rememberSaveable { mutableStateOf("") }
    var kind by rememberSaveable { mutableStateOf(SearchKind.Songs) }
    val artwork = (state as? EngineState.Ready)?.nowPlaying?.artwork

    val content: @Composable (Modifier) -> Unit = { modifier ->
        when (destination) {
            Destination.NowPlaying -> PlayerScreen(
                state = state,
                engine = engine,
                lyricsRepository = lyricsRepository,
                onGrantAccess = onGrantAccess,
                onOpenAppleMusic = onOpenAppleMusic,
                onPickFont = onPickFont,
                hasCustomFont = hasCustomFont,
                onResetFont = onResetFont,
                modifier = modifier,
            )

            Destination.Search -> SearchScreen(
                query = query,
                onQueryChange = { query = it },
                kind = kind,
                onKindChange = { kind = it },
                onOpenUrl = onOpenUrl,
                modifier = modifier,
            )
        }
    }

    CompositionLocalProvider(LocalContentColor provides Color.White) {
        Backdrop(artwork = artwork, modifier = Modifier.fillMaxSize()) {
            BoxWithConstraints(Modifier.fillMaxSize().safeDrawingPadding()) {
                if (maxWidth >= 600.dp) {
                    Row(Modifier.fillMaxSize()) {
                        SideRail(destination) { destination = it }
                        content(Modifier.weight(1f).fillMaxHeight())
                    }
                } else {
                    Column(Modifier.fillMaxSize()) {
                        content(Modifier.weight(1f).fillMaxWidth())
                        BottomBar(destination) { destination = it }
                    }
                }
            }
        }
    }
}

@Composable
private fun SideRail(selected: Destination, onSelect: (Destination) -> Unit) {
    Column(
        modifier = Modifier.width(92.dp).fillMaxHeight().padding(top = 36.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(18.dp),
    ) {
        NavButton(selected == Destination.NowPlaying, stringResource(R.string.nav_now_playing), { onSelect(Destination.NowPlaying) }) { NoteIcon(it) }
        NavButton(selected == Destination.Search, stringResource(R.string.nav_search), { onSelect(Destination.Search) }) { SearchIcon(it) }
    }
}

@Composable
private fun BottomBar(selected: Destination, onSelect: (Destination) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 24.dp, vertical = 10.dp)
            .glass(shape = CircleShape, tint = 0.1f, elevation = 8.dp)
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
    ) {
        NavButton(selected == Destination.NowPlaying, stringResource(R.string.nav_now_playing), { onSelect(Destination.NowPlaying) }) { NoteIcon(it) }
        NavButton(selected == Destination.Search, stringResource(R.string.nav_search), { onSelect(Destination.Search) }) { SearchIcon(it) }
    }
}

@Composable
private fun NavButton(
    selected: Boolean,
    label: String,
    onClick: () -> Unit,
    icon: @Composable (Color) -> Unit,
) {
    val tint = if (selected) Color.White else Color.White.copy(alpha = 0.6f)
    Column(
        modifier = Modifier.pressable(onClick).padding(4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            modifier = Modifier
                .size(52.dp)
                .then(if (selected) Modifier.glass(shape = CircleShape, tint = 0.22f, elevation = 0.dp) else Modifier),
            contentAlignment = Alignment.Center,
        ) {
            icon(tint)
        }
        Text(label, style = MaterialTheme.typography.labelSmall, color = tint)
    }
}
