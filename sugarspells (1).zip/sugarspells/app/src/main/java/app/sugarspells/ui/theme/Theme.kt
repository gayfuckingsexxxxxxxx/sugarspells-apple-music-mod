package app.sugarspells.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColors = lightColorScheme(
    primary = Color(0xFFD9638A),
    background = Color(0xFFFFF5F8),
    surface = Color(0xFFFFF5F8),
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFFFFA6C1),
    background = Color(0xFF1A1216),
    surface = Color(0xFF1A1216),
)

@Composable
fun SugarspellsTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    typography: Typography = AppTypography,
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        typography = typography,
        content = content,
    )
}
