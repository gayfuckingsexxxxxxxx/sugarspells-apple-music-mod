package app.sugarspells.playback

import android.graphics.Bitmap
import kotlinx.coroutines.flow.StateFlow

/** What the player UI needs to know about the current track. */
data class NowPlaying(
    val title: String,
    val artist: String,
    val album: String,
    val artwork: Bitmap?,
    val durationMs: Long,
    val isPlaying: Boolean,
    /** Position when the state was last reported, see [positionUpdatedAt]. */
    val positionMs: Long,
    /** [android.os.SystemClock.elapsedRealtime] at the moment [positionMs] was valid. */
    val positionUpdatedAt: Long,
    val speed: Float,
    val queue: List<QueueEntry> = emptyList(),
    val activeQueueId: Long = -1L,
)

/** One entry of the queue published by the Apple Music app (if it publishes one). */
data class QueueEntry(val id: Long, val title: String, val subtitle: String, val artwork: Bitmap?)

sealed interface EngineState {
    /** The user has not granted notification access yet (needed to read media sessions). */
    data object NoAccess : EngineState

    /** Access granted, but the Apple Music app has no active session. */
    data object NoSession : EngineState

    data class Ready(val nowPlaying: NowPlaying) : EngineState
}

/**
 * Playback backend. Phase 1 ships [AppleMusicSessionEngine] (free, controls the official app).
 * A MusicKit-based engine can be added later for people with an Apple Developer account.
 */
interface PlaybackEngine {
    val state: StateFlow<EngineState>

    fun start()
    fun stop()

    fun play()
    fun pause()
    fun next()
    fun previous()
    fun seekTo(positionMs: Long)
    fun skipToQueueItem(id: Long)
}
