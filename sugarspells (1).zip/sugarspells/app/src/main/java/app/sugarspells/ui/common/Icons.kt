package app.sugarspells.ui.common

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

@Composable
fun NoteIcon(tint: Color = Color.White, dimension: Dp = 26.dp) {
    Canvas(Modifier.size(dimension)) {
        val w = size.width
        drawCircle(tint, radius = w * 0.17f, center = Offset(w * 0.34f, w * 0.76f))
        drawLine(tint, Offset(w * 0.5f, w * 0.72f), Offset(w * 0.5f, w * 0.16f), strokeWidth = w * 0.1f, cap = StrokeCap.Round)
        drawLine(tint, Offset(w * 0.5f, w * 0.16f), Offset(w * 0.82f, w * 0.3f), strokeWidth = w * 0.1f, cap = StrokeCap.Round)
    }
}

@Composable
fun SearchIcon(tint: Color = Color.White, dimension: Dp = 26.dp) {
    Canvas(Modifier.size(dimension)) {
        val w = size.width
        drawCircle(tint, radius = w * 0.27f, center = Offset(w * 0.42f, w * 0.42f), style = Stroke(width = w * 0.1f))
        drawLine(tint, Offset(w * 0.63f, w * 0.63f), Offset(w * 0.86f, w * 0.86f), strokeWidth = w * 0.1f, cap = StrokeCap.Round)
    }
}

/** Speech bubble with lines: the lyrics toggle. */
@Composable
fun LyricsIcon(tint: Color = Color.White, dimension: Dp = 22.dp) {
    Canvas(Modifier.size(dimension)) {
        val w = size.width
        val stroke = w * 0.09f
        drawRoundRect(
            tint,
            topLeft = Offset(w * 0.1f, w * 0.12f),
            size = Size(w * 0.8f, w * 0.6f),
            cornerRadius = CornerRadius(w * 0.16f),
            style = Stroke(width = stroke),
        )
        val tail = Path().apply {
            moveTo(w * 0.26f, w * 0.7f)
            lineTo(w * 0.26f, w * 0.9f)
            lineTo(w * 0.46f, w * 0.72f)
        }
        drawPath(tail, tint, style = Stroke(width = stroke, cap = StrokeCap.Round))
        drawLine(tint, Offset(w * 0.28f, w * 0.34f), Offset(w * 0.72f, w * 0.34f), strokeWidth = stroke, cap = StrokeCap.Round)
        drawLine(tint, Offset(w * 0.28f, w * 0.5f), Offset(w * 0.56f, w * 0.5f), strokeWidth = stroke, cap = StrokeCap.Round)
    }
}

/** Three rows with bullets: the queue toggle. */
@Composable
fun QueueIcon(tint: Color = Color.White, dimension: Dp = 22.dp) {
    Canvas(Modifier.size(dimension)) {
        val w = size.width
        val stroke = w * 0.09f
        listOf(0.22f, 0.5f, 0.78f).forEach { y ->
            drawCircle(tint, radius = w * 0.05f, center = Offset(w * 0.14f, w * y))
            drawLine(tint, Offset(w * 0.3f, w * y), Offset(w * 0.9f, w * y), strokeWidth = stroke, cap = StrokeCap.Round)
        }
    }
}
