package app.sugarspells.ui.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

val GlassCorner = RoundedCornerShape(36.dp)

/**
 * "Liquid glass" look: translucent frosted tint, a bright specular rim that fades around the
 * edge, a soft highlight in the top-left corner and a gentle drop shadow.
 *
 * The blur comes from the backdrop itself (a blurred copy of the cover, see [app.sugarspells.ui.player.Backdrop]),
 * so the panels do not need to blur what is behind them.
 */
fun Modifier.glass(
    shape: Shape = GlassCorner,
    tint: Float = 0.14f,
    elevation: Dp = 24.dp,
): Modifier = this
    .shadow(
        elevation = elevation,
        shape = shape,
        ambientColor = Color.Black.copy(alpha = 0.25f),
        spotColor = Color.Black.copy(alpha = 0.3f),
    )
    .clip(shape)
    .background(
        Brush.verticalGradient(
            listOf(
                Color.White.copy(alpha = tint + 0.06f),
                Color.White.copy(alpha = (tint - 0.05f).coerceAtLeast(0.02f)),
            ),
        ),
    )
    .drawBehind {
        drawRect(
            Brush.radialGradient(
                colors = listOf(Color.White.copy(alpha = 0.22f), Color.Transparent),
                center = Offset(size.width * 0.12f, 0f),
                radius = size.maxDimension * 0.75f,
            ),
        )
    }
    .border(
        width = 1.2.dp,
        brush = Brush.linearGradient(
            listOf(
                Color.White.copy(alpha = 0.7f),
                Color.White.copy(alpha = 0.08f),
                Color.White.copy(alpha = 0.35f),
            ),
        ),
        shape = shape,
    )
