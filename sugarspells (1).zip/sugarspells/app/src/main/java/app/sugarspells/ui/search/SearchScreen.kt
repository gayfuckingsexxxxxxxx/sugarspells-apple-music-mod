package app.sugarspells.ui.search

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import app.sugarspells.R
import app.sugarspells.search.ItunesSearch
import app.sugarspells.search.SearchKind
import app.sugarspells.search.SearchResult
import app.sugarspells.ui.common.SelectableChip
import app.sugarspells.ui.common.pressable
import app.sugarspells.ui.common.rememberRemoteImage
import app.sugarspells.ui.theme.glass
import kotlinx.coroutines.delay
import java.util.Locale

/** Catalogue search through Apple's public iTunes Search API; results open in the Apple Music app. */
@Composable
fun SearchScreen(
    query: String,
    onQueryChange: (String) -> Unit,
    kind: SearchKind,
    onKindChange: (SearchKind) -> Unit,
    onOpenUrl: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    val api = remember { ItunesSearch() }
    val country = remember { Locale.getDefault().country.ifBlank { "US" } }
    var results by remember { mutableStateOf<List<SearchResult>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }

    LaunchedEffect(query, kind) {
        if (query.isBlank()) {
            results = emptyList()
            loading = false
            return@LaunchedEffect
        }
        loading = true
        delay(350) // debounce while typing
        results = api.search(query.trim(), kind, country)
        loading = false
    }

    Column(modifier.fillMaxSize().padding(horizontal = 32.dp, vertical = 32.dp)) {
        Text(stringResource(R.string.search_title), style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(16.dp))

        BasicTextField(
            value = query,
            onValueChange = onQueryChange,
            singleLine = true,
            textStyle = MaterialTheme.typography.bodyLarge.copy(color = Color.White),
            cursorBrush = SolidColor(Color.White),
            modifier = Modifier
                .fillMaxWidth()
                .glass(shape = CircleShape, tint = 0.12f, elevation = 6.dp)
                .padding(horizontal = 22.dp, vertical = 14.dp),
            decorationBox = { inner ->
                Box {
                    if (query.isEmpty()) {
                        Text(
                            stringResource(R.string.search_hint),
                            style = MaterialTheme.typography.bodyLarge,
                            color = Color.White.copy(alpha = 0.5f),
                        )
                    }
                    inner()
                }
            },
        )
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            SelectableChip(stringResource(R.string.search_songs), kind == SearchKind.Songs, { onKindChange(SearchKind.Songs) })
            SelectableChip(stringResource(R.string.search_albums), kind == SearchKind.Albums, { onKindChange(SearchKind.Albums) })
        }
        Spacer(Modifier.height(16.dp))

        Box(Modifier.weight(1f).fillMaxWidth()) {
            when {
                query.isBlank() -> Hint(stringResource(R.string.search_note))
                loading && results.isEmpty() ->
                    CircularProgressIndicator(
                        color = Color.White,
                        modifier = Modifier.size(28.dp).align(Alignment.Center),
                    )

                results.isEmpty() -> Hint(stringResource(R.string.search_empty))
                else -> LazyVerticalGrid(
                    columns = GridCells.Adaptive(320.dp),
                    horizontalArrangement = Arrangement.spacedBy(20.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxSize(),
                ) {
                    items(results) { result -> ResultRow(result, onOpenUrl) }
                }
            }
        }
    }
}

@Composable
private fun Hint(text: String) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text(
            text,
            style = MaterialTheme.typography.bodyMedium,
            color = Color.White.copy(alpha = 0.6f),
            textAlign = TextAlign.Center,
        )
    }
}

@Composable
private fun ResultRow(result: SearchResult, onOpenUrl: (String) -> Unit) {
    val image by rememberRemoteImage(result.artworkUrl)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .pressable { result.openUrl?.let(onOpenUrl) }
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier
                .size(64.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(Color.White.copy(alpha = 0.15f)),
        ) {
            image?.let { bitmap ->
                Image(
                    bitmap = bitmap,
                    contentDescription = null,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop,
                )
            }
        }
        Column(Modifier.weight(1f)) {
            Text(
                result.title,
                style = MaterialTheme.typography.titleMedium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                result.subtitle,
                style = MaterialTheme.typography.bodyMedium,
                color = Color.White.copy(alpha = 0.6f),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}
