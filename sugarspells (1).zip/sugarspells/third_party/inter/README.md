# Inter

The typeface used by sugarspells (Inter and Inter Display, static OTF files in `app/src/main/res/font/`).
Copyright The Inter Project Authors, licensed under the SIL Open Font License 1.1.
See `COPYRIGHT.txt` for the licence details shipped with the font package. Project: https://rsms.me/inter/
