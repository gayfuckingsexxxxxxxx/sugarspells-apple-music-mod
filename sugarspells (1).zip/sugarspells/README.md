# sugarspells'🍎🎵

An open source Android player for Apple Music, built with Kotlin, Jetpack Compose and Material 3.
It plays music through **your own official Apple Music account** - no piracy, no illegal downloads.

> Not affiliated with or endorsed by Apple Inc. Apple Music and MusicKit are trademarks of Apple Inc.

## What works today (session mode, free)
- Now Playing in an Apple Music-for-iPad style: cover, seek bar, transport, volume, synced lyrics with word-by-word highlight, queue
- Search the Apple Music catalogue (songs and albums) with Apple's public iTunes Search API; results open in the Apple Music app
- Sidebar on tablets, bottom bar on phones; blurred-cover backdrop; Inter typography or your own font files
- A gentle zoom/drift effect on the cover while playing (a visual effect, **not** Apple's motion artwork)

## What needs a paid Apple developer token (MusicKit mode, not available)
Your library and playlists, Apple's own motion artwork and Apple's word-synced lyrics are only served through the Apple Music API.
**AutoMix** is a feature of Apple's own app on Apple devices and is not available on Android; Apple Music for Android has Crossfade
(Automatic or 1-12 s) in its own settings, which keeps working because the audio still comes from Apple's app.

## Two playback modes
| Mode | Cost | What works |
|------|------|-----------|
| **Session mode** (default) | Free | Shows and controls what the official Apple Music app is playing (cover, progress, play/pause/next/previous), Apple TV-style animated player, synced lyrics from LRCLIB |
| **MusicKit mode** (planned) | Apple Developer Program (99 USD/year) | Catalog, library, search, playlists, motion artwork, word-synced lyrics |

Session mode needs no developer account or API keys: playback, DRM and your account stay inside Apple's own app.
Catalog, search and motion artwork come from the Apple Music API, which requires a paid developer token,
so those arrive with MusicKit mode (contributors with a membership welcome).

## Lyrics
Lyrics come from [LRCLIB](https://lrclib.net), a free, open, keyless database of time-synced lyrics. Timing is per line;
the word-by-word highlight is **estimated** from the line timing unless a record includes real word tags (those are used automatically).
Providers are pluggable (`LyricsProvider`). Musixmatch is not bundled: its official free plan returns only a 30% preview, and synced
lyrics need a paid commercial plan; unofficial access through keys extracted from its app breaks its terms and is not supported here.

## Requirements (session mode)
- Android 8.0+, internet (for lyrics) and the official Apple Music app, signed in with an active subscription
- Notification access enabled for sugarspells (the app guides you)

## Privacy
Android only lets an app read another app's media session if it holds notification access. sugarspells uses it **only** to read the
`com.apple.android.music` media session. It never reads, stores or sends notification content, The only network request is the lyrics lookup, which sends the song title, artist, album and duration to LRCLIB.

## Install (APK)
Every push builds an APK in GitHub Actions: open the latest run of **CI** and download the `sugarspells-debug-apk` artifact.
Tagging a version (`git tag v0.2.0 && git push --tags`) publishes the APK as a GitHub Release.
To install, allow "install unknown apps" for your browser or file manager. These are debug-signed builds for personal use.

## Design
Landscape-first, made for tablets: cover, seek bar, transport and volume on the left, lyrics on the right, over an animated
backdrop that follows the cover's colours. Inspired by Apple Music on iPad; no Apple assets are used. Typeface: [Inter](third_party/inter/README.md)
(Apple's San Francisco cannot be redistributed outside Apple platforms).

### Using your own font
Tap **Choose font** in the player and pick one or several `.ttf`/`.otf` files (one per weight works; the weight is guessed from
the file name: Regular, Medium, Semibold, Bold...). They are copied to the app's private storage on your device, never into the
repo or the APK. **Reset font** goes back to Inter. You are responsible for having the right to use any font you load.

## Build
1. Open in Android Studio, or run `gradle wrapper` once and then `./gradlew assembleDebug`.
2. For MusicKit mode (later): copy `local.properties.example` to `local.properties` and add your keys; download Apple's
   MusicKit for Android SDK into `app/libs/` (proprietary, git-ignored, never commit it).

## Status
See [CHANGELOG.md](CHANGELOG.md) and the milestones in Issues.

## License
[MIT](LICENSE) - applies to this project's code only, not to Apple's SDK or content.
