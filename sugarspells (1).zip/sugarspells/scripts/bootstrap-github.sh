#!/usr/bin/env bash
# Creates milestones and issues. Requires GitHub CLI (`gh auth login`) and a pushed repo.
set -euo pipefail
repo="$(gh repo view --json nameWithOwner -q .nameWithOwner)"

ms() { gh api "repos/$repo/milestones" -f title="$1" -f description="$2" >/dev/null; }
issue() { gh issue create --title "$1" --body "$2" --milestone "$3" >/dev/null; }

ms "v0.1 - Login"   "Apple Music authentication"
ms "v0.2 - Player"  "Playback, queue, library, search, playlists"
ms "v0.3 - Artwork" "Motion artwork with static fallback"
ms "v0.4 - Lyrics"  "Word-by-word synced lyrics"
ms "v0.5 - Glass UI" "Liquid glass design and adaptive layout"

issue "feat(auth): developer token (JWT) generation"          "Sign the JWT from keys in local.properties. No secrets in the repo." "v0.1 - Login"
issue "feat(auth): Music User Token sign-in flow"              "Sign in with the user's own Apple Music account." "v0.1 - Login"
issue "feat(playback): PlaybackEngine interface + MusicKit impl" "Interface plus a no-op implementation so CI builds without Apple's SDK." "v0.2 - Player"
issue "feat(player): controls, queue and now playing screen"   "Play/pause, next/previous, queue." "v0.2 - Player"
issue "feat(library): library, search and playlists"           "Apple Music API catalog + library endpoints." "v0.2 - Player"
issue "feat(artwork): motion artwork with static fallback"     "Use editorial video when the API offers it." "v0.3 - Artwork"
issue "feat(lyrics): word-synced lyrics, degrade to line"      "Parse timed lyrics from the API." "v0.4 - Lyrics"
issue "feat(ui): liquid glass components"                      "Translucent blurred panels, glowing borders, rounded corners." "v0.5 - Glass UI"
issue "feat(ui): adaptive layout (sidebar / bottom nav)"       "Sidebar on tablets, bottom bar on phones." "v0.5 - Glass UI"
issue "feat(ui): cover-derived player background"              "Extract palette from artwork." "v0.5 - Glass UI"

issue "feat(lyrics): Musixmatch provider using the user's own official API key" "Official plans: free = 30% preview, synced/richsync = paid. Implement behind LyricsProvider, key from local.properties. Do NOT use keys extracted from Musixmatch's apps." "v0.4 - Lyrics"
issue "research(lyrics): sources with real word-level timings" "Find legal providers with word timings; LrcParser already supports enhanced <mm:ss.xx> tags." "v0.4 - Lyrics"
issue "feat(player): seek bar, queue and Inter typography" "Draggable progress bar, queue if the session exposes it, bundle Inter (OFL)." "v0.2 - Player"
issue "feat(library): library and playlists (MusicKit mode)" "Needs an Apple Developer token + Music User Token. Blocked for free session mode." "v0.2 - Player"
issue "feat(artwork): Apple motion artwork (MusicKit mode)" "Needs the Apple Music API (editorialVideo). Session mode uses a simulated zoom/drift instead." "v0.3 - Artwork"
