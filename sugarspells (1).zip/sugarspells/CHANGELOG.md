# Changelog

All notable changes to this project are documented here.
Format based on [Keep a Changelog](https://keepachangelog.com/).

## [Unreleased]

### Added
- Catalogue search (songs, albums) through the iTunes Search API; tap a result to open it in Apple Music
- Queue pane (when the Apple Music app publishes its queue) and lyrics/queue toggles like on iPad
- Sidebar navigation on tablets and bottom bar on phones
- Cover zoom/drift effect while playing
- Load your own fonts from device storage ("Choose font" / "Reset font"), kept out of the repo and the APK
- Tablet-first landscape design modelled on Apple Music for iPad: cover, title, draggable seek bar, vector transport icons, system volume slider, lyrics on the right with progressive blur
- Inter / Inter Display typography (OFL) with an Apple-like weight hierarchy
- Glass modifier (frosted tint, specular rim) and a blurred-cover backdrop (Android 12+)
- GitHub Actions now uploads a debug APK on every run, and `release.yml` publishes APKs on version tags
- Apple TV-style player: cover on the left and lyrics on the right on tablets/landscape; compact layout on phones
- Animated backdrop with colours extracted from the cover, cover cross-fade and bounce on pause/play
- Synced lyrics from LRCLIB with an animated active line and word-by-word highlight (estimated unless the source provides word tags); tap a line to seek
- LRC parser with enhanced word tags, `LyricsProvider` interface and in-memory cache, with unit tests
- Phase 1 (free): `PlaybackEngine` interface and `AppleMusicSessionEngine`, which reads and controls the official Apple Music app via its media session
- Now playing screen (cover, title, artist, progress, previous/play-pause/next) and notification-access onboarding
- English and Spanish strings
- Project scaffold: Gradle (Kotlin DSL), Compose, Material 3, light/dark theme
- Launcher icon (adaptive + legacy) and app name
- CI workflow (build + lint) and GitHub bootstrap script for milestones and issues
- MIT license, README, CONTRIBUTING

### Changed
- INTERNET permission is back, used only for the lyrics lookup
