package app.sugarspells.lyrics

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class LrcParserTest {

    @Test
    fun parsesLineSyncedAndEstimatesWords() {
        val lrc = "[ar:Someone]\n[00:10.00]Hello big world\n[00:14.50]Second line\n[00:20.00]"
        val lyrics = LrcParser.parse(lrc, 30_000)
        assertNotNull(lyrics)
        lyrics!!
        assertEquals(2, lyrics.lines.size)
        assertEquals(10_000L, lyrics.lines[0].startMs)
        assertEquals(14_500L, lyrics.lines[0].endMs)
        assertEquals(listOf("Hello ", "big ", "world"), lyrics.lines[0].words.map { it.text })
        assertFalse(lyrics.wordSynced)
    }

    @Test
    fun parsesEnhancedWordTags() {
        val lrc = "[00:01.00]<00:01.00>Hel<00:01.50>lo <00:02.00>world"
        val lyrics = LrcParser.parse(lrc, 30_000)!!
        assertTrue(lyrics.wordSynced)
        assertEquals(3, lyrics.lines[0].words.size)
        assertEquals(listOf(1_000L, 1_500L, 2_000L), lyrics.lines[0].words.map { it.startMs })
    }

    @Test
    fun repeatedTimestampsProduceOneLineEach() {
        val lyrics = LrcParser.parse("[00:05.00][00:15.00]La la", 20_000)!!
        assertEquals(listOf(5_000L, 15_000L), lyrics.lines.map { it.startMs })
    }

    @Test
    fun returnsNullWithoutTimestamps() {
        assertNull(LrcParser.parse("just plain text", 10_000))
    }
}
