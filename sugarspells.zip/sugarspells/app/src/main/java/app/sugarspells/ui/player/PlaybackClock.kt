package app.sugarspells.ui.player

import android.os.SystemClock
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import app.sugarspells.playback.NowPlaying
import kotlinx.coroutines.delay

/** Live playback position in ms, interpolated between the player's reports (~30 fps). */
@Composable
fun rememberPositionMs(np: NowPlaying): State<Long> {
    val position = remember { mutableLongStateOf(0L) }
    LaunchedEffect(np.positionMs, np.positionUpdatedAt, np.isPlaying, np.speed, np.durationMs) {
        position.longValue = np.positionAt(SystemClock.elapsedRealtime())
        while (np.isPlaying) {
            delay(33)
            position.longValue = np.positionAt(SystemClock.elapsedRealtime())
        }
    }
    return position
}

private fun NowPlaying.positionAt(now: Long): Long {
    val elapsed = if (isPlaying) ((now - positionUpdatedAt) * speed).toLong() else 0L
    val max = if (durationMs > 0) durationMs else Long.MAX_VALUE
    return (positionMs + elapsed).coerceIn(0L, max)
}
