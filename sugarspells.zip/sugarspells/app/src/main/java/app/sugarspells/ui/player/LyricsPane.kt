package app.sugarspells.ui.player

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import app.sugarspells.lyrics.LyricLine
import app.sugarspells.lyrics.Lyrics

private val Dim = Color.White.copy(alpha = 0.45f)
private val Bright = Color.White

/**
 * Apple TV-style lyrics: the active line is centred and enlarged, words light up as they
 * are sung, other lines dim away. Tapping a line seeks to it.
 */
@Composable
fun LyricsPane(
    lyrics: Lyrics,
    position: State<Long>,
    onSeek: (Long) -> Unit,
    large: Boolean,
    modifier: Modifier = Modifier,
) {
    val lines = lyrics.lines
    val listState = rememberLazyListState()
    val activeIndex by remember(lines) {
        derivedStateOf { lines.indexOfLast { it.startMs <= position.value }.coerceAtLeast(0) }
    }
    LaunchedEffect(activeIndex) {
        listState.animateScrollToItem(activeIndex)
    }
    val style: TextStyle = (if (large) MaterialTheme.typography.headlineLarge else MaterialTheme.typography.headlineSmall)
        .copy(fontWeight = FontWeight.Bold)

    BoxWithConstraints(
        modifier = modifier
            .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
            .drawWithContent {
                drawContent()
                drawRect(
                    Brush.verticalGradient(
                        0f to Color.Transparent,
                        0.12f to Color.Black,
                        0.85f to Color.Black,
                        1f to Color.Transparent,
                    ),
                    blendMode = BlendMode.DstIn,
                )
            },
    ) {
        LazyColumn(
            state = listState,
            contentPadding = PaddingValues(top = maxHeight * 0.28f, bottom = maxHeight * 0.6f),
        ) {
            itemsIndexed(lines, key = { index, _ -> index }) { index, line ->
                val active = index == activeIndex
                val scale by animateFloatAsState(if (active) 1f else 0.82f, tween(450), label = "lineScale")
                val alpha by animateFloatAsState(if (active) 1f else 0.4f, tween(450), label = "lineAlpha")
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .graphicsLayer {
                            scaleX = scale
                            scaleY = scale
                            this.alpha = alpha
                            transformOrigin = TransformOrigin(0f, 0.5f)
                        }
                        .clickable { onSeek(line.startMs) }
                        .padding(vertical = 10.dp),
                ) {
                    if (active) {
                        ActiveLine(line, position, style)
                    } else {
                        Text(line.text, style = style, color = Bright)
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ActiveLine(line: LyricLine, position: State<Long>, style: TextStyle) {
    FlowRow {
        line.words.forEach { word ->
            val span = (word.endMs - word.startMs).coerceAtLeast(1)
            val progress = ((position.value - word.startMs).toFloat() / span).coerceIn(0f, 1f)
            Text(
                text = word.text,
                style = style,
                color = lerp(Dim, Bright, progress),
                modifier = Modifier.graphicsLayer { translationY = -progress * 5.dp.toPx() },
            )
        }
    }
}
