package app.sugarspells.playback

import android.service.notification.NotificationListenerService

/**
 * Intentionally empty. Android only lets an app read other apps' media sessions when it
 * owns an enabled NotificationListenerService; this class exists for that permission only.
 */
class NotificationAccessService : NotificationListenerService()
