package app.sugarspells.lyrics

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.math.abs

/**
 * Free, keyless community lyrics database (https://lrclib.net). Returns time-synced
 * lyrics per line; word timings are estimated unless the record carries word tags.
 */
class LrclibProvider : LyricsProvider {
    override val name = "LRCLIB"

    override suspend fun fetch(query: TrackQuery): Lyrics? = withContext(Dispatchers.IO) {
        if (query.title.isBlank()) return@withContext null
        runCatching { exact(query) ?: search(query) }.getOrNull()
    }

    private fun exact(q: TrackQuery): Lyrics? {
        val params = buildString {
            append("track_name=").append(enc(q.title))
            append("&artist_name=").append(enc(q.artist))
            if (q.album.isNotBlank()) append("&album_name=").append(enc(q.album))
            if (q.durationMs > 0) append("&duration=").append(q.durationMs / 1000)
        }
        val body = httpGet("$BASE/get?$params") ?: return null
        return toLyrics(JSONObject(body), q)
    }

    private fun search(q: TrackQuery): Lyrics? {
        val body = httpGet("$BASE/search?track_name=${enc(q.title)}&artist_name=${enc(q.artist)}")
            ?: return null
        val results = JSONArray(body)
        val wantedSec = q.durationMs / 1000
        var best: JSONObject? = null
        var bestGap = Long.MAX_VALUE
        for (i in 0 until results.length()) {
            val candidate = results.getJSONObject(i)
            if (candidate.isNull("syncedLyrics")) continue
            val gap = if (wantedSec > 0) abs(candidate.optLong("duration") - wantedSec) else 0L
            if (wantedSec > 0 && gap > 3) continue // likely a different version
            if (gap < bestGap) {
                best = candidate
                bestGap = gap
            }
        }
        return best?.let { toLyrics(it, q) }
    }

    private fun toLyrics(record: JSONObject, q: TrackQuery): Lyrics? {
        if (record.isNull("syncedLyrics")) return null
        return LrcParser.parse(record.getString("syncedLyrics"), q.durationMs, name)
    }

    private fun httpGet(url: String): String? {
        val conn = URL(url).openConnection() as HttpURLConnection
        return try {
            conn.connectTimeout = 8_000
            conn.readTimeout = 8_000
            conn.setRequestProperty("User-Agent", "sugarspells/0.2.0")
            if (conn.responseCode != HttpURLConnection.HTTP_OK) null
            else conn.inputStream.bufferedReader().use { it.readText() }
        } finally {
            conn.disconnect()
        }
    }

    private fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")

    private companion object {
        const val BASE = "https://lrclib.net/api"
    }
}
