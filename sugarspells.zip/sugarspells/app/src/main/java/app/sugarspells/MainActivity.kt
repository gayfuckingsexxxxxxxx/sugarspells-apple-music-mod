package app.sugarspells

import android.content.ActivityNotFoundException
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import app.sugarspells.lyrics.LrclibProvider
import app.sugarspells.lyrics.LyricsRepository
import app.sugarspells.playback.APPLE_MUSIC_PACKAGE
import app.sugarspells.playback.AppleMusicSessionEngine
import app.sugarspells.playback.PlaybackEngine
import app.sugarspells.ui.player.PlayerScreen
import app.sugarspells.ui.theme.SugarspellsTheme

class MainActivity : ComponentActivity() {

    private lateinit var engine: PlaybackEngine
    private val lyricsRepository = LyricsRepository(listOf(LrclibProvider()))

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        engine = AppleMusicSessionEngine(this)
        setContent {
            SugarspellsTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    val state by engine.state.collectAsState()
                    PlayerScreen(
                        state = state,
                        engine = engine,
                        lyricsRepository = lyricsRepository,
                        onGrantAccess = ::openNotificationAccessSettings,
                        onOpenAppleMusic = ::openAppleMusic,
                    )
                }
            }
        }
    }

    // Re-check on every return (e.g. coming back from the notification access settings).
    override fun onStart() {
        super.onStart()
        engine.start()
    }

    override fun onStop() {
        engine.stop()
        super.onStop()
    }

    private fun openNotificationAccessSettings() {
        startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
    }

    private fun openAppleMusic() {
        val launch = packageManager.getLaunchIntentForPackage(APPLE_MUSIC_PACKAGE)
        try {
            startActivity(launch ?: Intent(Intent.ACTION_VIEW, android.net.Uri.parse("market://details?id=$APPLE_MUSIC_PACKAGE")))
        } catch (_: ActivityNotFoundException) {
            // No Play Store available; nothing else to do.
        }
    }
}
