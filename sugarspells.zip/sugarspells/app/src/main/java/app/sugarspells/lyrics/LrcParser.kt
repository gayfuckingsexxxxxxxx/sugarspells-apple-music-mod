package app.sugarspells.lyrics

/**
 * Parses LRC lyrics: `[mm:ss.xx]line`. Supports repeated leading timestamps and the
 * "enhanced" word tags `<mm:ss.xx>word`. When a line has no word tags, word timings are
 * estimated from the line's duration.
 */
object LrcParser {
    private val LEADING_TAGS = Regex("""^\s*(?:\[\d{1,3}:\d{2}(?:[.:]\d{1,3})?\])+""")
    private val LINE_TAG = Regex("""\[(\d{1,3}):(\d{2})(?:[.:](\d{1,3}))?\]""")
    private val WORD_TAG = Regex("""<(\d{1,3}):(\d{2})(?:[.:](\d{1,3}))?>""")
    private val WHITESPACE = Regex("\\s+")

    private data class Raw(val startMs: Long, val text: String)

    fun parse(lrc: String, trackDurationMs: Long = 0L, source: String = "LRC"): Lyrics? {
        val raws = ArrayList<Raw>()
        for (line in lrc.lineSequence()) {
            val leading = LEADING_TAGS.find(line) ?: continue
            val text = line.substring(leading.value.length)
            for (tag in LINE_TAG.findAll(leading.value)) {
                raws += Raw(toMs(tag), text)
            }
        }
        if (raws.isEmpty()) return null
        raws.sortBy { it.startMs }

        var wordSynced = false
        val lines = ArrayList<LyricLine>()
        raws.forEachIndexed { i, raw ->
            val start = raw.startMs
            val rawEnd = if (i + 1 < raws.size) raws[i + 1].startMs else lastLineEnd(start, trackDurationMs)
            val end = maxOf(rawEnd, start + 1)
            val trimmed = raw.text.trim()
            if (trimmed.isEmpty()) return@forEachIndexed // instrumental gap
            val real = parseEnhanced(raw.text, end)
            if (real != null) wordSynced = true
            lines += LyricLine(start, end, real ?: estimateWords(trimmed, start, end))
        }
        return if (lines.isEmpty()) null else Lyrics(lines, wordSynced, source)
    }

    private fun parseEnhanced(text: String, lineEnd: Long): List<LyricWord>? {
        val tags = WORD_TAG.findAll(text).toList()
        if (tags.isEmpty()) return null
        val words = ArrayList<LyricWord>()
        tags.forEachIndexed { i, tag ->
            val from = tag.range.last + 1
            val to = if (i + 1 < tags.size) tags[i + 1].range.first else text.length
            val chunk = text.substring(from, to)
            if (chunk.isBlank()) return@forEachIndexed
            val start = toMs(tag)
            val end = if (i + 1 < tags.size) toMs(tags[i + 1]) else lineEnd
            words += LyricWord(start, maxOf(end, start), chunk.trimStart())
        }
        return words.ifEmpty { null }
    }

    private fun estimateWords(text: String, start: Long, end: Long): List<LyricWord> {
        val tokens = text.split(WHITESPACE).filter { it.isNotEmpty() }
        val total = tokens.sumOf { it.length }.coerceAtLeast(1)
        val lineMs = (end - start).coerceAtLeast(1)
        // People rarely sing for the whole gap until the next line: cap the sung span.
        val sungMs = minOf(lineMs, maxOf(800L, total * 85L))
        var cursor = start
        return tokens.mapIndexed { i, token ->
            val isLast = i == tokens.lastIndex
            val wordEnd = if (isLast) start + sungMs else cursor + sungMs * token.length / total
            val word = LyricWord(cursor, wordEnd, if (isLast) token else "$token ")
            cursor = wordEnd
            word
        }
    }

    private fun lastLineEnd(start: Long, trackDurationMs: Long): Long {
        val cap = start + 8_000
        return if (trackDurationMs > start) minOf(trackDurationMs, cap) else cap
    }

    private fun toMs(m: MatchResult): Long {
        val minutes = m.groupValues[1].toLong()
        val seconds = m.groupValues[2].toLong()
        val frac = m.groupValues[3]
        val fracMs = when (frac.length) {
            0 -> 0L
            1 -> frac.toLong() * 100
            2 -> frac.toLong() * 10
            else -> frac.take(3).toLong()
        }
        return minutes * 60_000 + seconds * 1_000 + fracMs
    }
}
