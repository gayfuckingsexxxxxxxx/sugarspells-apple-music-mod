package app.sugarspells.lyrics

/** Identifies a track for lyrics lookup. */
data class TrackQuery(
    val title: String,
    val artist: String,
    val album: String,
    val durationMs: Long,
)

/** [text] keeps its trailing space so words can be laid out one by one. */
data class LyricWord(val startMs: Long, val endMs: Long, val text: String)

data class LyricLine(val startMs: Long, val endMs: Long, val words: List<LyricWord>) {
    val text: String get() = words.joinToString("") { it.text }.trim()
}

/**
 * @property wordSynced true when the source provided real per-word timings;
 * false when word timings are estimated from line timings.
 */
data class Lyrics(val lines: List<LyricLine>, val wordSynced: Boolean, val source: String)

interface LyricsProvider {
    val name: String
    suspend fun fetch(query: TrackQuery): Lyrics?
}

/** Tries each provider in order and keeps a small in-memory cache. */
class LyricsRepository(private val providers: List<LyricsProvider>) {

    private val cache = LinkedHashMap<TrackQuery, Lyrics>()

    suspend fun load(query: TrackQuery): Lyrics? {
        synchronized(cache) { cache[query]?.let { return it } }
        for (provider in providers) {
            val found = provider.fetch(query)
            if (found != null) {
                synchronized(cache) {
                    if (cache.size >= 40) cache.remove(cache.keys.first())
                    cache[query] = found
                }
                return found
            }
        }
        return null
    }
}
