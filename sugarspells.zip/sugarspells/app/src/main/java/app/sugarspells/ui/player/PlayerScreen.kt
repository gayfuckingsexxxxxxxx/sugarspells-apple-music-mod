package app.sugarspells.ui.player

import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.sugarspells.R
import app.sugarspells.lyrics.Lyrics
import app.sugarspells.lyrics.LyricsRepository
import app.sugarspells.lyrics.TrackQuery
import app.sugarspells.playback.EngineState
import app.sugarspells.playback.NowPlaying
import app.sugarspells.playback.PlaybackEngine

private sealed interface LyricsUi {
    data object Loading : LyricsUi
    data object Missing : LyricsUi
    data class Found(val lyrics: Lyrics) : LyricsUi
}

@Composable
fun PlayerScreen(
    state: EngineState,
    engine: PlaybackEngine,
    lyricsRepository: LyricsRepository,
    onGrantAccess: () -> Unit,
    onOpenAppleMusic: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val artwork = (state as? EngineState.Ready)?.nowPlaying?.artwork
    CompositionLocalProvider(LocalContentColor provides Color.White) {
        Backdrop(artwork = artwork, modifier = modifier.fillMaxSize()) {
            when (state) {
                EngineState.NoAccess -> CenteredMessage(
                    title = stringResource(R.string.access_title),
                    body = stringResource(R.string.access_body),
                    action = stringResource(R.string.access_action),
                    onAction = onGrantAccess,
                )

                EngineState.NoSession -> CenteredMessage(
                    title = stringResource(R.string.no_session_title),
                    body = stringResource(R.string.no_session_body),
                    action = stringResource(R.string.open_apple_music),
                    onAction = onOpenAppleMusic,
                )

                is EngineState.Ready -> NowPlayingLayout(state.nowPlaying, engine, lyricsRepository, onOpenAppleMusic)
            }
        }
    }
}

@Composable
private fun CenteredMessage(title: String, body: String, action: String, onAction: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .safeDrawingPadding()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Text(title, style = MaterialTheme.typography.headlineSmall, textAlign = TextAlign.Center)
        Spacer(Modifier.height(12.dp))
        Text(body, style = MaterialTheme.typography.bodyMedium, textAlign = TextAlign.Center)
        Spacer(Modifier.height(24.dp))
        Button(onClick = onAction) { Text(action) }
    }
}

@Composable
private fun NowPlayingLayout(
    np: NowPlaying,
    engine: PlaybackEngine,
    repository: LyricsRepository,
    onOpenAppleMusic: () -> Unit,
) {
    val position = rememberPositionMs(np)
    val query = remember(np.title, np.artist, np.album, np.durationMs) {
        TrackQuery(np.title, np.artist, np.album, np.durationMs)
    }
    val lyricsUi by produceState<LyricsUi>(LyricsUi.Loading, query) {
        value = LyricsUi.Loading
        val found = if (query.title.isBlank()) null else repository.load(query)
        value = if (found != null) LyricsUi.Found(found) else LyricsUi.Missing
    }

    BoxWithConstraints(Modifier.fillMaxSize().safeDrawingPadding()) {
        val wide = maxWidth >= 600.dp && maxWidth > maxHeight
        if (wide) {
            // Apple TV style: cover + controls on the left, lyrics on the right.
            Row(
                modifier = Modifier.fillMaxSize().padding(40.dp),
                horizontalArrangement = Arrangement.spacedBy(48.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Column(Modifier.weight(0.42f), horizontalAlignment = Alignment.CenterHorizontally) {
                    Cover(np, Modifier.fillMaxWidth(0.9f).aspectRatio(1f))
                    Spacer(Modifier.height(24.dp))
                    TrackInfo(np, centered = true)
                    Spacer(Modifier.height(16.dp))
                    ProgressBar(np, position)
                    Controls(np, engine)
                    TextButton(onClick = onOpenAppleMusic) {
                        Text(stringResource(R.string.open_apple_music), color = Color.White.copy(alpha = 0.7f))
                    }
                }
                LyricsArea(lyricsUi, position, engine::seekTo, large = true, modifier = Modifier.weight(0.58f).fillMaxHeight())
            }
        } else {
            Column(Modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    Cover(np, Modifier.size(96.dp))
                    Column(Modifier.weight(1f)) { TrackInfo(np, centered = false) }
                }
                LyricsArea(lyricsUi, position, engine::seekTo, large = false, modifier = Modifier.weight(1f).fillMaxWidth())
                ProgressBar(np, position)
                Controls(np, engine)
            }
        }
    }
}

@Composable
private fun Cover(np: NowPlaying, modifier: Modifier) {
    // Shrinks when paused, springs back when playing.
    val scale by animateFloatAsState(
        targetValue = if (np.isPlaying) 1f else 0.88f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow),
        label = "coverScale",
    )
    val shape = RoundedCornerShape(24.dp)
    Box(
        modifier = modifier
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .shadow(24.dp, shape)
            .clip(shape)
            .background(Color.White.copy(alpha = 0.15f)),
        contentAlignment = Alignment.Center,
    ) {
        Crossfade(targetState = np.artwork, animationSpec = tween(700), label = "coverFade") { art ->
            if (art != null) {
                val image = remember(art) { art.asImageBitmap() }
                Image(
                    bitmap = image,
                    contentDescription = null,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop,
                )
            } else {
                Text("🍎🎵", fontSize = 48.sp)
            }
        }
    }
}

@Composable
private fun TrackInfo(np: NowPlaying, centered: Boolean) {
    val align = if (centered) TextAlign.Center else TextAlign.Start
    Text(
        np.title,
        style = MaterialTheme.typography.titleLarge,
        fontWeight = FontWeight.Bold,
        textAlign = align,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
        modifier = Modifier.fillMaxWidth(),
    )
    Text(
        listOf(np.artist, np.album).filter { it.isNotBlank() }.joinToString(" - "),
        style = MaterialTheme.typography.bodyMedium,
        color = Color.White.copy(alpha = 0.7f),
        textAlign = align,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
        modifier = Modifier.fillMaxWidth(),
    )
}

@Composable
private fun ProgressBar(np: NowPlaying, position: State<Long>) {
    val pos = position.value
    val fraction = if (np.durationMs > 0) (pos.toFloat() / np.durationMs).coerceIn(0f, 1f) else 0f
    Column(Modifier.fillMaxWidth().padding(top = 8.dp)) {
        LinearProgressIndicator(
            progress = { fraction },
            modifier = Modifier.fillMaxWidth(),
            color = Color.White,
            trackColor = Color.White.copy(alpha = 0.25f),
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(formatTime(pos), style = MaterialTheme.typography.labelSmall)
            Text(formatTime(np.durationMs), style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
private fun Controls(np: NowPlaying, engine: PlaybackEngine) {
    val colors = ButtonDefaults.textButtonColors(contentColor = Color.White)
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically,
    ) {
        TextButton(onClick = engine::previous, colors = colors) { Text("⏮", fontSize = 28.sp) }
        TextButton(onClick = { if (np.isPlaying) engine.pause() else engine.play() }, colors = colors) {
            Text(if (np.isPlaying) "⏸" else "▶", fontSize = 40.sp)
        }
        TextButton(onClick = engine::next, colors = colors) { Text("⏭", fontSize = 28.sp) }
    }
}

@Composable
private fun LyricsArea(
    ui: LyricsUi,
    position: State<Long>,
    onSeek: (Long) -> Unit,
    large: Boolean,
    modifier: Modifier,
) {
    Box(modifier, contentAlignment = Alignment.Center) {
        when (ui) {
            LyricsUi.Loading -> CircularProgressIndicator(color = Color.White, modifier = Modifier.size(28.dp))
            LyricsUi.Missing -> Text(
                stringResource(R.string.no_lyrics),
                color = Color.White.copy(alpha = 0.6f),
                textAlign = TextAlign.Center,
            )

            is LyricsUi.Found -> LyricsPane(ui.lyrics, position, onSeek, large, Modifier.fillMaxSize())
        }
    }
}

private fun formatTime(ms: Long): String {
    val totalSeconds = (ms / 1000).coerceAtLeast(0)
    return "%d:%02d".format(totalSeconds / 60, totalSeconds % 60)
}
