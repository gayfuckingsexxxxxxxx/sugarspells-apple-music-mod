package app.sugarspells.ui.player

import android.graphics.Bitmap
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.palette.graphics.Palette
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private val DefaultA = Color(0xFF3A2430)
private val DefaultB = Color(0xFF1A1216)

/** Slowly drifting colour blobs taken from the cover; colours cross-fade on track change. */
@Composable
fun Backdrop(
    artwork: Bitmap?,
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit,
) {
    var target by remember { mutableStateOf(DefaultA to DefaultB) }
    LaunchedEffect(artwork) {
        target = if (artwork == null) {
            DefaultA to DefaultB
        } else {
            val palette = withContext(Dispatchers.Default) {
                Palette.from(artwork).maximumColorCount(16).generate()
            }
            val a = palette.getDarkVibrantColor(palette.getDominantColor(DefaultA.toArgbInt()))
            val b = palette.getMutedColor(palette.getVibrantColor(DefaultB.toArgbInt()))
            Color(a) to Color(b)
        }
    }
    val colorA by animateColorAsState(target.first, tween(1_400), label = "backdropA")
    val colorB by animateColorAsState(target.second, tween(1_400), label = "backdropB")

    val transition = rememberInfiniteTransition(label = "backdropDrift")
    val drift by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(16_000, easing = LinearEasing), RepeatMode.Reverse),
        label = "drift",
    )

    Box(
        modifier = modifier
            .background(Color.Black)
            .drawBehind {
                val radius = size.maxDimension * 0.95f
                drawRect(
                    Brush.radialGradient(
                        listOf(colorA, Color.Transparent),
                        center = Offset(size.width * (0.15f + 0.45f * drift), size.height * (0.2f + 0.2f * drift)),
                        radius = radius,
                    ),
                )
                drawRect(
                    Brush.radialGradient(
                        listOf(colorB, Color.Transparent),
                        center = Offset(size.width * (0.85f - 0.45f * drift), size.height * (0.85f - 0.25f * drift)),
                        radius = radius,
                    ),
                )
                drawRect(Color.Black.copy(alpha = 0.35f))
            },
        content = content,
    )
}

private fun Color.toArgbInt(): Int = this.toArgb()
